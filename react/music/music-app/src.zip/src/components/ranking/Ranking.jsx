import React, { Component } from 'react';
class Ranking extends Component {
  state = {  }
  render() { 
    return ( 
      <div>
        Ranking
      </div>
     );
  }
}
 
export default Ranking;